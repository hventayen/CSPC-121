# Description
Describe your program in your own words.
For this project we would ask the user to put in times for their schedule and we would take it and check if they conflict with other times of appointment. If they did then we would ask them to add another time that doesn't confict with the other appointment times.
# Challenges encountered
Describe the challenges you encountered while creating your program.
Challenges were finding out what the logic would be for the operators. There's a lot of ways that we can check if the appointment times would be conflicting or not and making it efficient was hard.
# Things I've learned
What is the most important thing you've learned from creating your program?
The most important thing I learned was seeing how two classes can be in one program and how they can interact. This was the first time seeing this and it was interesting to see how they would work in one hpp file. Also being efficient in logic was very good to see more ways that my code could have been simplified.
