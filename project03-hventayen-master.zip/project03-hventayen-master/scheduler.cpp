#include <iostream>
#include <string>
#include "scheduler.hpp"
#include <fstream>
#include <sstream>
#include <cmath>
const int OBJECT = 100;
bool load_schedule(std::string const & myFile, Course array[], int & size)
{
  const int HOURS = 23;
  const int MIN = 59;
  const int MAGIC = 5;
  std::string word;
  std::string fullStart;
  std::string fullEnd;
  int startHour;
  int startMin;
  int endHour;
  int endMin;
  int count = 1;
  int errorCount = 0;

  std::ifstream schedule;
  schedule.open(myFile);
  if (schedule)
  {
    while (getline(schedule, word) && errorCount == 0)
    {
      if (count == 1)
      {
        array[size].set_course_name(word);
      }
      // std::cout << count << word << std::endl;

      if (count == 2 && word.empty())
      {
        std::cout << "Error: Unable to get a location.";
        errorCount++;
        break;
      }

      if (count == 2)
      {
        array[size].set_location(word);
      }

      if (count == 3 && word.empty())
      {
        std::cout << "Error: Unable to retrieve a weekly schedule."
                  << std::endl;
        errorCount++;
        break;
      }
      if (count == 3)
      {
        if (word.length() > 0)
        {
          if (word != "M" && word != "T" && word != "W" && word != "H" &&
              word != "F" && word != "S" && word != "MW" && word != "MF" &&
              word != "TH")
          {
            std::cout << "Error, weekly schedule symbol " << word << ".\n";
            errorCount++;
            break;
          }
        }
        array[size].set_weekly_schedule(word);
      }

      if (count == 4 && word.empty())
      {
        std::cout << "Error: Unable to get a valid start time.";
        errorCount++;
        break;
      }
      if (count == 4)
      {
        fullStart = word;

        char colon = ' ';
        std::stringstream ss(word);
        ss >> startHour >> colon >> startMin;
        if (colon != ':')
        {
          std::cout << "Error: Unable to get a valid start time";
          errorCount++;
          break;
        }

        if (startHour >= 0 && startHour <= HOURS)
        {
          if (startMin >= 0 && startMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: Unable to use " << word << " as start time."
                      << std::endl;
            errorCount++;
            break;
          }
        }
        else
        {
          std::cout << "Error: Unable to use " << word << " as start time."
                    << std::endl;
          errorCount++;
          break;
        }
        int x;
        x = (startHour * OBJECT) + startMin;
        array[size].set_start_time(x);
        // array[size].set_start_string(word);
      }

      if (count == MAGIC && word.empty())
      {
        std::cout << "Error: Unable to get a valid end time.";
        errorCount++;
        break;
      }
      if (count == MAGIC)
      {
        fullEnd = word;
        char colon2 = ' ';
        std::stringstream ww(word);
        ww >> endHour >> colon2 >> endMin;
        if (colon2 != ':')
        {
          std::cout << "Error: Unable to gather end time.";
          errorCount++;
          break;
        }
        if (endHour >= 0 && endHour <= HOURS)
        {
          if (endMin >= 0 && endMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: " << word
                      << " is unable to be used as a valid end time."
                      << std::endl;
            errorCount++;
          }
        }
        else
        {
          std::cout << "Error: " << word
                    << " is unable to be used as a valid end time."
                    << std::endl;
          errorCount++;
          break;
        }

        if (startHour > endHour || (startHour == endHour && startMin > endMin))
        {
          if (startMin != endMin)
          {
            std::cout << "Error: The start time " << fullStart
                      << " should happen before the end time " << fullEnd << "."
                      << std::endl;
            break;
          }
        }
        int n;
        n = (endHour * OBJECT) + endMin;
        array[size].set_end_time(n);
        // array[size].set_end_string(word);
        count = 0;
        size++;
      }

      count++;
    }
    // While loop ends here
    if (count == 2)
    {
      std::cout << "Error: Unable to get location." << std::endl;
      errorCount++;
    }
    else if (count == 3 && errorCount == 0)
    {
      std::cout << "Error: Unable to get a weekly schedule." << std::endl;
      errorCount++;
    }
    else if (count == 4)
    {
      std::cout << "Error: Unable to get a valid start time." << std::endl;
      errorCount++;
    }
    else if (count == MAGIC)
    {
      std::cout << "Error: Unable to get a valid end time." << std::endl;
      errorCount++;
    }
    else if (errorCount == 0)
    {
      std::cout << "Valid file!" << std::endl;
    }
    schedule.close();
  }
  else
  {
    std::cout << "Error: The file does not exist. Invalid file." << std::endl;
    errorCount++;
  }
  if (errorCount > 0)
  {
    std::cout << "Invalid file." << std::endl;
    return false;
  }
  return true;
}
// Display all the schedule parts
void display_courses(Course array[], int size)
{
  for (int i = 0; i < size; i++)
  {
    array[i].display();
    std::cout << "\n";
  }
}
// Operator functions
bool TimeSpan::operator<(const TimeSpan & time)
{
  return (end_time_ < time.start_time());
}

bool TimeSpan::operator>(const TimeSpan & time)
{
  return (start_time_ > time.end_time());
}
// Check if there's a conflict
bool has_conflict(TimeSpan temp, TimeSpan appointments[], int size)
{
  // checks whole array with temp
  bool isConflict = false;
  for (int i = 0; i < size; i++)
  {
    // Operator overload calls
    // Can assume that the first timespan is greater than the second TimeSpan
    // for a single temp object
    // Might need to accomodate two cases: when the two times of temp is
    // greater than or less than
    if (!(temp > appointments[i] || temp < appointments[i]))
    {
      isConflict = true;
      break;
    }
  }
  return isConflict;
}
