# Description
Describe your program in your own words.
The program makes a schedule for students when they send in their information.
However, now we are making it efficient by using pointers, making new areas of
memory then deleting it once we are done with it.
# Challenges encountered
Describe the challenges you encountered while creating your program.
It was very hard to see how we can deallocate the objects once we were done
with them, especially when we are in the middle of a loop.
# Things I've learned
What is the most important thing you've learned from creating your program?
I learned how pointers can work with classes and functions, and the right time
to deallocate memory, and specifically to deallocate it in the main file when
we know that we are for sure done with the space.
