#include "get_longest_string.hpp"
#include <array>
#include <iostream>
#include <string>
std::string get_longest_string(std::string input[], int ARRAY_SIZE)
{
  int largest = 0;
  std::string largestString;
  // Loops to see if input is biggest
  for (int i = 0; i < ARRAY_SIZE; i++)
  {
    // changes var if string is bigger than another string
    if (input[i].size() > largest)
    {
      largest = input[i].size();
      largestString = input[i];
    }
  }
  return largestString;
}
