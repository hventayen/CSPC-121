#include <array>
#include <iostream>
#include <string>
// Prototype
std::string get_longest_string(std::string input[], int ARRAY_SIZE);
