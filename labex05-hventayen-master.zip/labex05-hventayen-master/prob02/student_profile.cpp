#include "student_profile.hpp"
#include <iostream>
#include <string>
// Function definition, pass in array
double average_gpa(Student stud_arr[], unsigned int size)
{
  double sum = 0;
  // Add all gpa's
  for (int i = 0; i < size; i++)
  {
    sum += stud_arr[i].gpa();
  }
  sum /= size;
  return sum;
}
