#include <iostream>
#include <string>
#ifndef _STUDENT_PROFILE_HPP_
#define _STUDENT_PROFILE_HPP_
class Student
{
private:
  // Initialize variables
  std::string name_;
  std::string cmajor_;
  unsigned int cwid_;
  double gpa_;

public:
  // Must have setters and getters
  void set_name(std::string s) { name_ = s; }
  void set_cmajor(std::string m) { cmajor_ = m; }
  void set_cwid(unsigned int c) { cwid_ = c; }
  void set_gpa(double g) { gpa_ = g; }
  std::string name() const { return name_; }
  std::string cmajor() const { return cmajor_; }
  unsigned int cwid() const { return cwid_; }
  double gpa() const { return gpa_; }
};
// Function prototype
double average_gpa(Student stud_arr[], unsigned int size);
#endif
