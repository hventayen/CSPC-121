#include <iostream>

int main()
{
  // Declare initial size of array
  const int SIZE = 5;
  // Create integer array with initial values
  int a1[] = {15, 60, 7, 98, 48};

  // Create boolean array using the given SIZE
 
  // Call the find_evens function and provide necessary
  // parameters

  // Print contents of the array
  for (int i = 0; i < SIZE; i++)
  {
    std::cout << a2[i];
  }
  std::cout << std::endl;

  return 0;
}
