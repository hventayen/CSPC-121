#include <iostream>
// Prototype
double calculate_avg(double * arrayptr, int size);
