#include "calculate_avg.hpp"
#include <iostream>
// Header
double calculate_avg(double * arrayptr, int size)
{
  // Check if size > 0
  if (size > 0)
  {
    double sum = 0;
    for (int i = 0; i < size; i++)
    {
      sum += *(arrayptr + i);
    }
    return (sum / size);
  }
  return 0;
}
