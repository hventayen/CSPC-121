#include "min.hpp"
#include <iostream>
// Header
int min(int * arrayptr, int size)
{
  // Initialize pointer
  int min = *arrayptr;
  for (int i = 0; i < size; i++)
  {
    if (*(arrayptr + i) < min)
    {
      min = *(arrayptr + i);
    }
  }
  return min;
}
