#include <iostream>
// Prototype
int min(int * arrayptr, int size);
