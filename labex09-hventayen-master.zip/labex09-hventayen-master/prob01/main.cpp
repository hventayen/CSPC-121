#include "car_comp.hpp"
#include <iostream>
#include <string>
int main()
{
  // Create four instances of a `Car` object using the different
  // constructors

  // Create a Car object using the default constructor and call it c1
  Car c1;
  // Create an `Identifier` object with the following information:
  // Name - Honda, ID - 3, License plate - 7B319X4
  std::string ci_name = "Honda";
  int ci_id = 3;
  std::string ci_license = "7B319X4";
  Identifier ci(ci_name, ci_id, ci_license);
  // Create a `Car` object using the constructor that accepts an `Identifier`
  // object and pass in the `Identifier` object you just created; call it c2
  Car c2(ci);
  // Create a `Date` object with the following information:
  // Day - 4, Month - 11, Year - 2018
  int cd_day = 4;
  int cd_month = 11;
  int cd_year = 2018;
  Date cd(cd_day, cd_month, cd_year);
  // Create a `Car` object using the constructor that accepts a `Date` object
  // and pass in the `Date` object you just created; call it c3
  Car c3(cd);
  // Create a `Car` object using the constructor that accepts an `Identifier`
  // and `Date` object then pass in the `Identifier` and `Date` objects you
  // created previously; call it c4
  Car c4(ci, cd);
  // Call the print member function for `c1`
  c1.print();
  std::cout << "\n";

  // Call the print member function for `c2`
  c2.print();
  std::cout << "\n";

  // Call the print member function for `c3`
  c3.print();
  std::cout << "\n";

  // Call the print member function for `c4`
  c4.print();
  std::cout << "\n";

  // Create an instance of the `Identifier` object using the default constructor
  Identifier identifier;
  // Create an instance of the `Date` object using the default constructor
  Date date;
  // Call the `set_identity` member function on `c4` and pass in the identifier
  // you just created
  c4.set_identity(identifier);
  // Call the `set_release_date` member function on `c4` and pass in the date
  // object you just created
  c4.set_release_date(date);
  // Call the print member function for `c4`
  c4.print();
  return 0;
}
