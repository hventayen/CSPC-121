// "If not defined" then it makes pet.hpp file
#ifndef _PET_HPP_
// Defines the file (both used as a safeguard if no hpp file)
#define _PET_HPP_
#include <iostream>
#include <string>

class Breed
{
private:
  std::string species_;
  std::string name_;
  std::string color_;

public:
  Breed() { species_ = "Dog", name_ = "Pug", color_ = "Fawn"; }
  Breed(const std::string & s, const std::string & n, const std::string & c)
      : species_(s), name_(n), color_(c)
  {
  }
  void set_species(const std::string & s) { species_ = s; }
  void set_name(const std::string & n) { name_ = n; }
  void set_color(const std::string & c) { color_ = c; }
  std::string species() const { return species_; }
  std::string name() const { return name_; }
  std::string color() const { return color_; }
};

class Pet
{
private:
  std::string name_;
  Breed breed_;
  double weight_;

public:
  // When setting member initialization lists, it's just an efficient way to
  // set numbers to initialize them. Pointers make member initialization lists
  // impossible because if you have an array of pointers that don't have a value
  // yet, the member initialization lists will get mad because they require you
  // to have a set value already, while the regular constructors give you a
  // choice
  Pet() : Pet("Doug", Breed(), 15.6) {}
  // Used for when we already have a breed object made from main.cpp
  Pet(const std::string & name, const Breed & b, double w)
      : name_(name), breed_(b), weight_(w)
  {
  }
  // Used for when we don't have breed made from main.cpp and we have three
  // strings
  Pet(const std::string & name, const std::string & s, const std::string & n,
      const std::string & c, double w)
      // We can use breed_(s, n, c) because breed_ Breed(s, n, c) is already
      // done, since breed_ is of Breed class. However, we can only use the
      // constructors from the other class because we are dealing with a breed
      // object
      : name_(name), breed_(s, n, c), weight_(w)
  {
  }
  void set_name(const std::string & name) { name_ = name; }
  // Accounts for two scenarios:
  // Used if a breed object is already made to be set
  void set_breed(const Breed & b) { breed_ = b; }
  // Used if no breed object is already made and there are three strings
  void set_breed(const std::string & s, const std::string & n,
                 const std::string & c)
  {
    // Since you are not exactly dealing with breed object, you use Breed
    // constructor
    breed_ = Breed(s, n, c);
  }
  void set_weight(double w) { weight_ = w; }
  // If const outside, doesn't mean that its too big, but that the value can't
  // change, since we don't want it to change for a single pet
  std::string name() const { return name_; }
  Breed breed() const { return breed_; }
  double weight() const { return weight_; }
  void print() const
  {
    std::cout << "Printing Pets:" << std::endl
              << "Pet 1"
              << std::endl
              // Doing extra work if you use name()
              << "Name: " << name_
              << std::endl
              // breed_ is using methods from a different class. must use
              // .species()
              << "Species: " << breed_.species() << std::endl
              << "Breed: " << breed_.name() << std::endl
              << "Color: " << breed_.color() << std::endl
              << "Weight: " << weight_ << " lbs" << std::endl;
  }
};

#endif
