#include <iostream> 
using namespace std;
int main()
{
  // gets credit score
  int creditScore;
  cout << "Thank you for applying for the Tuffy Credit card. Please enter your "
          "credit score.\n";
  cin >> creditScore;
  cout << "Credit Score: " << creditScore << "\n\n";
  // sorts credit card by score
  if (creditScore >= 0 && creditScore <= 850)
  {
    if (creditScore >= 800)
    {
      cout << "You are eligible for the Platinum Tuffy Card.\nThank you for "
              "using our program, please come again!\n";
    }
    else if (creditScore >= 670)
    {
      cout << "You are eligible for the Gold Tuffy Card.\nThank you for using "
              "our program, please come again!\n";
    }
    else if (creditScore >= 580)
    {
      cout << "You are eligible for the Silver Tuffy Card.\nThank you for using"
              " our program, please come again!\n";
    }
    else
    {
      cout << "Unfortunately, you are ineligible for Tuffy credit cards at "
              "the moment. Please try again at a later date.\n"
              "Thank you for using our program,"
              " please come again!\n";
    }
  }
  else
  {
    cout << "This is an invalid credit score. Please run the program again and "
            "provide a valid credit score.\n";
  }
  return 0;
}
