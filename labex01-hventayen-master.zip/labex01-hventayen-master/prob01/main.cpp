#include <iomanip>
#include <iostream>

using namespace std;
const double TAX = 0.075;
const double FIX = 0.01;
int main()
{
  double mealCost;
  double tipPercentage;
  cout << "Please input meal cost: ";
  cin >> mealCost;
  cout << "Please input tip percentage: ";
  cin >> tipPercentage;
  double tipAmount = mealCost * tipPercentage * FIX;
  cout << "\nRestaurant Bill\n";
  cout << "====================\n";
  cout << setprecision(2) << fixed << "Subtotal: $" << mealCost;
  double tax = mealCost * TAX;
  cout << "\nTaxes: $" << tax;
  cout << setprecision(2) << fixed << "\nTip: $" << tipAmount;
  cout << "\n====================\n";
  double total = mealCost + tax + tipAmount;
  cout << setprecision(2) << fixed << "Total: $" << total << "\n";
  return 0;
}
