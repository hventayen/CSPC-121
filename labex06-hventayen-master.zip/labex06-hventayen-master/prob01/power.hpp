#include <iostream>
// Prototype
int power(int base, unsigned int exp);
