#include "power.hpp"
#include <cmath>
#include <iostream>

int power(int base, unsigned int exp)
{
  if (exp == 0)
  {
    // To stop the loop
    return 1;
  }
  else
  {
    // Must get to 1 to end function
    return base * power(base, exp - 1);
  }
}
