#include "array_max.hpp"
#include <iostream>

int array_max(int arr[], int arrSize)
{
  // Make sure size is a valid value in array
  if (arrSize <= 0)
  {
    return -1;
  }
  // Debug code
  std::cout << arrSize << std::endl;
  int val1 = arr[arrSize - 1];
  // Base case
  if (arrSize == 1)
  {
    return val1;
  }
  else
  {
    // Gives us all the val2's in the stack
    int val2 = array_max(arr, arrSize - 1);
    // Starts testing all the val2's
    if (val1 > val2)
    {
      return val1;
    }
    else
    {
      return val2;
    }
  }
}
