#include <iostream>
// Prototype
int array_max(int arr[], int arrSize);
