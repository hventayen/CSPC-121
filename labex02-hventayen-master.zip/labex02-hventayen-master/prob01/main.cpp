#include <iostream>

int main()
{
  int startNum;
  int multNum;
  int sum = 0;
  std::cout << "Please enter a number: ";
  std::cin >> startNum;
  std::cout << "Number of times to be added: ";
  std::cin >> multNum;
  // multNum can't be negative
  if (multNum >= 0)
  {
    // multiply
    for (int i = 0; i < multNum; i++)
    {
      sum += startNum;
    }
    std::cout << "The sum is " << sum << std::endl;
  }
  else
  {
    std::cout << "\nRepetitions can't be negative\n";
  }
}
