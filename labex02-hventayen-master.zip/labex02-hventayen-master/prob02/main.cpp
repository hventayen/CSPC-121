#include <iostream>

int main()
{
  int base;
  int power;
  int product = 1;
  // user input
  std::cout << "Please enter the base number: ";
  std::cin >> base;
  std::cout << "Please enter the power: ";
  std::cin >> power;
  // exponent
  if (power >= 0)
  {
    for (int i = 0; i < power; i++)
    {
      product = product * base;
    }
    std::cout << base << " ^ " << power << " = " << product << std::endl;
  }
  else
  {
    std::cout << "Negative powers are currently unsupported." << std::endl;
  }
}
