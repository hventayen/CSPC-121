#ifndef _STATISTICS_CALCULATOR_HPP_
#define _STATISTICS_CALCULATOR_HPP_
#include <iostream>
// Vector library
#include <vector>

class StatisticsCalculator
{
private:
  // Makes a list of doubles
  std::vector<double> data_set_;

public:
  void add_data(double value) { data_set_.push_back(value); }
  double data_at(int index)
  {
    // Refers to the first element in the vector
    auto p = data_set_.begin();
    int count = 0;
    // Allows looping
    while (p != data_set_.end())
    {
      // Finds number at that index
      if (index == count)
      {
        // Refers to the double at that index
        return *p;
      }
      p++;
      count++;
    }
    return 0.00;
  }
  int size_of_data() { return data_set_.size(); }
  double mean()
  {
    if (data_set_.empty())
    {
      return 0.00;
    }
    double sum = 0.00;
    int val = 0;
    // std::vector<double>::iterator v = data_set_.begin();
    auto v = data_set_.begin();
    while (v != data_set_.end())
    {
      sum += *v++;
      val++;
    }
    return (sum / val);
  }
};
#endif
