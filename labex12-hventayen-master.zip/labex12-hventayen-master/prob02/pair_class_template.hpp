#ifndef _PAIR_CLASS_TEMPLATE_HPP_
#define _PAIR_CLASS_TEMPLATE_HPP_
#include <iostream>
// Must make all the object types of type T
template <typename T> class MyPair
{
private:
  T value1_;
  T value2_;

public:
  // Constructors
  MyPair(T val1, T val2) : value1_(val1), value2_(val2) {}
  // Getters
  T value1() const { return value1_; }
  T value2() const { return value2_; }
  // Display fuctions
  void display() { std::cout << "[" << value1_ << ", " << value2_ << "]"; }
  void display_reverse()
  {
    std::cout << "[" << value2_ << ", " << value1_ << "]";
  }
  // Gets the max value
  T max_value() const
  {
    if (value1_ > value2_)
    {
      return value1_;
    }
    return value2_;
  }
  // Gets the min value
  T min_value() const
  {
    if (value1_ < value2_)
    {
      return value1_;
    }
    return value2_;
  }
  // Swaps value
  void swap_value()
  {
    T val;
    val = value1_;
    value1_ = value2_;
    value2_ = val;
  }
};
#endif
