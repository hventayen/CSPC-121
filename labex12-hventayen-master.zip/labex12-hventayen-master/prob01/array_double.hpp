#ifndef _ARRAY_DOUBLE_HPP_
#define _ARRAY_DOUBLE_HPP_
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
class Exception
{
private:
  std::string message_;

protected:
  Exception() : Exception("") {}

public:
  Exception(const std::string & msg) : message_(msg) {}
  std::string message() const { return message_; }
  // Used to make overall output
  void set_message(const std::string & msg) { message_ = msg; }
};

class IndexOutOfRangeException : public Exception
{
public:
  IndexOutOfRangeException(int ix, int size)
  {
    std::stringstream ss;
    ss << "Invalid index " << ix << " for an array with " << size << " element"
       << (size == 1 ? "" : "s") << ". Value must be between 0 and " << size - 1
       << '.';
    set_message(ss.str());
  }
};
// Kind of like if else statements or a break or a return
class InvalidArrayLengthException : public Exception
{
  // TODO(labex): Create non-default constructor
public:
  InvalidArrayLengthException(int size)
  {
    // Converts size into a string to be used to set the message
    std::stringstream ss;
    ss << "Invalid number of elements (" << size
       << "). Value must be a positive integer.";
    set_message(ss.str());
  }
};
// Deals with the arrays and formatting them
class ArrayDouble
{
private:
  double * array_;
  int num_;

public:
  // Implemented in cpp file
  ArrayDouble(int size);
  ~ArrayDouble();

  double & operator[](int ix) const;
  void display() const;
};

#endif
