#include "array_double.hpp"
#include <iomanip>
#include <iostream>
// TODO(labex): Implement the ArrayDouble class' nondefault constructor
ArrayDouble::ArrayDouble(int size) : array_(nullptr), num_(0)
{
  if (size < 0)
  {
    // Throw exceptions so the code after doesn't get executed
    throw InvalidArrayLengthException(size);
  }
  num_ = size;
  array_ = new double[size];
  for (int i = 0; i < size; i++)
  {
    array_[i] = 0;
  }
}
// TODO(labex): Impelment the ArrayDouble class' destructor
ArrayDouble::~ArrayDouble() { delete[] array_; }
// TODO(labex): Implement the ArrayDoublle class' operator[] member function
//              (operator overloading)
double & ArrayDouble::operator[](int ix) const
{
  // Must make sure it doesn't go out of range
  if (ix < 0 || ix >= num_)
  {
    throw IndexOutOfRangeException(ix, num_);
  }
  return array_[ix];
}
// TODO(labex): Implement the ArrayDouble class' display() member function
void ArrayDouble::display() const
{
  if (num_ == 0)
  {
    std::cout << "Array is empty." << std::endl;
  }
  else
  {
    std::cout << "Array contents: ";
    for (int i = 0; i < num_; i++)
    {
      // Must make sure that the first element has .00 at the end
      if (i == 0)
      {
        std::cout << std::fixed;
        std::cout << std::setprecision(2) << array_[0] << std::fixed << " ";
      }
      else
      {
        std::cout << std::setprecision(2) << array_[i] << std::fixed << " ";
      }
    }
    std::cout << std::endl;
  }
}
