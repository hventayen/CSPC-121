#ifndef _FIND_NUMBER_HPP_
#define _FIND_NUMBER_HPP_
#include <iostream>

class Numbers
{
private:
  // Private members
  int * values_;
  int capacity_;
  void init();

public:
  // Default constructor
  Numbers()
  {
    capacity_ = 10;
    values_ = new int[10];
    init();
  }
  // Non-default constructor
  Numbers(int c)
  {
    capacity_ = c;
    values_ = new int[c];
    init();
  }
  // Destructor sice we dynamically allocate array
  ~Numbers()
  {
    delete[] values_;
    // Must set it to nullptr
    values_ = nullptr;
  }
  // Getter
  int capacity() { return capacity_; }
  // Displays array
  void display_array()
  {
    for (int i = 0; i < capacity_; i++)
    {
      std::cout << *(values_ + i) << " ";
    }
    std::cout << std::endl;
  }
  // Finds copies in array
  void find_number(int n)
  {
    for (int i = 0; i < capacity_; i++)
    {
      if (*(values_ + i) == n)
      {
        std::cout << n << " is in the array" << std::endl;
      }
    }
  }
};
#endif
