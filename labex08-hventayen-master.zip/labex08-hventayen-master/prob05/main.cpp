#include <iostream>

int main()
{
  // Create an instance of the ShoppingList object

  // Call the add_item member function to add the 6 items into the shopping list

  // Call the print_list member function to display the list

  return 0;
}
