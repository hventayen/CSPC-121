#ifndef _CUP_HPP_
#define _CUP_HPP_
#include <iostream>
#include <string>

class Cup
{
  // Private variables
private:
  std::string drink_type_;
  double fluid_oz_;

public:
  // Default constructor if no preference
  Cup()
  {
    drink_type_ = "Water";
    fluid_oz_ = 16.0;
  }
  // Non-default constructor if preference
  Cup(const std::string & d, double f)
  {
    drink_type_ = d;
    fluid_oz_ = f;
  }
  // Subtracts drink amount
  void drink(double amount)
  {
    fluid_oz_ -= amount;
    if (fluid_oz_ < 0)
    {
      fluid_oz_ = 0;
    }
  }
  // Adds drink amount
  void refill(double amount)
  {
    fluid_oz_ += amount;
    if (fluid_oz_ < 0)
    {
      fluid_oz_ = 0;
    }
  }
  // Get a completely new drink
  void new_drink(const std::string & w, double f)
  {
    drink_type_ = w;
    fluid_oz_ = f;
  }
  // Take out the current drink
  void empty()
  {
    drink_type_ = "nothing";
    fluid_oz_ = 0;
  }
  std::string drink_type() const { return drink_type_; }
  double fluid_oz() const { return fluid_oz_; }
};

#endif
