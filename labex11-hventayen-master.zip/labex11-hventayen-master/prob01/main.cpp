#include "car.hpp"
#include <iomanip>
#include <iostream>

int main()
{
  int choice;
  std::string name;
  int year;
  double tank;
  double mpg;
  double speed;

  // declare a pointer to a Car object here and set it to nullptr
  Car * cptr = nullptr;
  std::cout << "Ubiquitous on-board driving management software test: - "
               "Gas/battery level sensor - \n";
  std::cout << "What type of car is being tested?\n";
  std::cout << "1 - Gasoline Car\n";
  std::cout << "2 - Electric Car\n";
  std::cout << "0 - Exit\n";
  std::cin >> choice;
  std::cin.ignore();

  if (choice == 1)
  {
    std::cout << "What is the name of the car? ";
    std::getline(std::cin, name);
    std::cout << "What year is the car? ";
    std::cin >> year;
    std::cout << "How many gallons of gas can this car store? ";
    std::cin >> tank;
    std::cout << "How much MPG does this car have? ";
    std::cin >> mpg;

    // Use the car pointer declared above to dynamically declare an object of
    // type GasolineCar using the non default constructor with the user's
    // input
    // Makes for a specific pointer to a specific function
    cptr = new GasolineCar(name, year, tank, mpg);
    std::cout << "How fast do you want to drive this car per hour? ";
    std::cin >> speed;
    int hours = 0;
    do
    {
      hours++;
      // call the drive function on the car pointer to drive the car
      cptr->drive(speed);
    } while (!(cptr->is_empty())/* Repeat the loop while the car's fuel is NOT empty */);

    std::cout << "It took " << name << " about " << hours
              << " hour(s) of driving to empty the tank\n";
  }
  else if (choice == 2)
  {
    std::cout << "What is the name of the car? ";
    std::getline(std::cin, name);
    std::cout << "What year is the car? ";
    std::cin >> year;

    // Use the car pointer declared above to dynamically declare an object of
    // type ElectricCar using the non default constructor with the user's
    // input
    cptr = new ElectricCar(name, year);
    std::cout << "How fast do you want to drive this car per hour? ";
    std::cin >> speed;
    int hours = 0;
    do
    {
      hours++;
      // call the drive function on the car pointer to drive the car
      cptr->drive(speed);
    } while (!(cptr->is_empty())/* Repeat the loop while the car's fuel is NOT empty */);

    std::cout << "It took " << name << " about " << hours
              << " hour(s) of driving to empty the battery\n";
  }
  else if (choice == 0)
  {
    std::cout << "Shutting down...\n";
  }
  else
  {
    std::cout << "Error - Shutting down...\n";
  }
  // Delete the car pointer and set it to nullptr
  // Must delete to get new ptr
  delete cptr;
  cptr = nullptr;
  return 0;
}
