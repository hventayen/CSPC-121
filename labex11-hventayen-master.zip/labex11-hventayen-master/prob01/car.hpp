#include <iostream>

// Car history references:
// https://www.loc.gov/rr/scitech/mysteries/auto.html
// https://www.mercedes-benz.com/en/mercedes-benz/classic/history/benz-patent-motor-car/

class Car
{
  // Private members
private:
  std::string name_;
  int year_;
  double speed_;

public:
  // Constructors
  Car() : Car("Steam automobile", 1769) {}
  Car(const std::string & name, int year) : name_(name), year_(year), speed_(0)
  {
  }
  // Setters and getters
  void set_name(const std::string & name) { name_ = name; }
  void set_year(int year) { year_ = year; }
  std::string name() const { return name_; }
  int year() const { return year_; }
  double speed() const { return speed_; }
  // Create the virtual functions as described in the readme
  // drive()
  // Gets called if its the base class function
  virtual void drive(double cptr) { speed_ = cptr; }
  // and
  // is_empty()
  virtual bool is_empty() { return false; }
};

class ElectricCar : public Car
{
  // Private members
private:
  double battery_percentage_;

public:
  // Constructors
  ElectricCar(const std::string & n, int y) : Car(n, y)
  {
    battery_percentage_ = 100.0;
  }
  ElectricCar() : Car("Electric carriage", 1832)
  {
    battery_percentage_ = 100.0;
  }
  // You have to refer to an object if you want to use specific functions
  bool is_empty() override { return (battery_percentage_ == 0); }
  void drive(double s) override
  {
    // Checks the battery percentage if you can drive
    if (battery_percentage_ > 0)
    {
      Car::drive(s);
      battery_percentage_ -= (s / 4);
    }
    if (battery_percentage_ < 0)
    {
      battery_percentage_ = 0;
    }
    if (battery_percentage_ <= 0)
    {
      Car::drive(0);
    }
  }
};

class GasolineCar : public Car
{
private:
  double tank_;
  double mpg_;

public:
  // Constructors
  GasolineCar(const std::string & n, int y, double t, double m) : Car(n, y)
  {
    tank_ = t;
    mpg_ = m;
  }
  GasolineCar() : Car("Gasoline car", 1885)
  {
    tank_ = 12;
    mpg_ = 24;
  }
  // Getters
  bool is_empty() override { return (tank_ == 0); }
  void drive(double s) override
  {
    // Checks the tank if you can drive
    if (tank_ > 0)
    {
      Car::drive(s);
      tank_ -= (s / mpg_);
    }
    if (tank_ < 0)
    {
      tank_ = 0;
    }
    if (tank_ <= 0)
    {
      Car::drive(0);
    }
  }
};
// Implement the ElectricCar and GasolineCar classes below
