#ifndef _WEAPONS_HPP_
#define _WEAPONS_HPP_
#include <cstdlib>
#include <iostream>
#include <random>
class Weapon
{
  // Private Members
private:
  int attack_min_;
  int attack_max_;
  std::string name_;

public:
  // Constructors
  Weapon() : Weapon(1, 2, "weapon") {}
  Weapon(int min, int max, const std::string & name)
      : attack_min_(min), attack_max_(max), name_(name)
  {
  }
  // Setters and getters
  void set_attack_min(int min) { attack_min_ = min; }
  void set_attack_max(int max) { attack_max_ = max; }
  void set_name(const std::string & name) { name_ = name; }
  int attack_min() { return attack_min_; }
  int attack_max() { return attack_max_; }
  std::string name() const { return name_; }
  virtual int attack()
  {
    int random = rand();
    int dmg;
    dmg = (random % (attack_max() - attack_min())) + attack_min_;
    return dmg;
  }
};

class Daggers : public Weapon
{
private:
  // Private members
  int crit_;
  int crit_dice_;

public:
  // Constructors
  Daggers() : Weapon(2, 3, "daggers")
  {
    crit_ = 1;
    crit_dice_ = 18;
  }
  Daggers(int min, int max, const std::string & name, int crit, int dice)
      : Weapon(min, max, name)
  {
    crit_ = crit;
    crit_dice_ = dice;
  }
  // Setters and getters
  void set_crit(int c) { crit_ = c; }
  void set_crit_dice(int cr) { crit_dice_ = cr; }
  int crit() { return crit_; }
  int crit_dice() { return crit_dice_; }
  int attack() override
  {
    int random;
    int damage1;
    int damage2;
    // Gets random numbers to get specific dmg types
    random = (rand() % 20) + 1;
    damage1 = (random % (attack_max() - attack_min())) + attack_min();
    if (random >= crit_dice_)
    {
      damage1 = (damage1 * crit_);
    }
    damage2 = (random % (attack_max() - attack_min())) + attack_min();
    if (random >= crit_dice_)
    {
      damage2 = (damage2 * crit_);
    }
    return (damage1 + damage2);
  }
};

class ShortSword : public Weapon
{
  // Private members
private:
  int multiplier_;

public:
  // Public members
  ShortSword() : Weapon(6, 7, "shortsword") { multiplier_ = 1; }
  ShortSword(int min, int max, const std::string & name, int mult)
      : Weapon(min, max, name)
  {
    multiplier_ = mult;
  }
  // Setters and getters
  int multiplier() { return multiplier_; }
  void set_multiplier(int m) { multiplier_ = m; }
  int attack() override
  {
    // Gets random numbers for specific dmg type
    int dmg;
    int random;
    random = (rand() % multiplier_) + 1;
    dmg = (random % (attack_max() - attack_min())) + attack_min();
    return (dmg * random);
  }
};

class Enemy : public Weapon
{
  // Private members
private:
  std::string name_;
  int health_;

public:
  // Constructors
  Enemy() : name_("dragon") { health_ = 500; }
  Enemy(const std::string & name, int health) : name_(name), health_(health) {}
  // Setters and getters
  void set_name(const std::string & n) { name_ = n; }
  void set_health(int h) { health_ = h; }
  std::string name() const { return name_; }
  int health() { return health_; }
  void receive_attack(Weapon * wptr)
  {
    // Takes note of all attacks
    int atk = wptr->attack();
    health_ -= atk;
    std::cout << wptr->name() << " dealt " << atk << " damage to " << name_
              << std::endl;
    if (health_ <= 0)
    {
      std::cout << name_ << " has been slain!" << std::endl;
    }
  }
};

#endif
