# Description
Describe your program in your own words.
My program displays multiple people's schedules. However, it uses arrays so the objects in the file get put into an array so they can be used for being displayed when everything has been checked for errors and loaded.
# Challenges encountered
Describe the challenges you encountered while creating your program.
It was hard figuring out how the code from project 1 worked in project 2, being in a function. There was so much code to think about that I could not keep track of how my variables would mix in with my class with the private and publix variables.
# Things I've learned
What is the most important thing you've learned from creating your program?
I learned that code can be reused for another purpose. I also learned that there are many ways to do the same thing in code, such as my counter method to check each schedule for errors.
