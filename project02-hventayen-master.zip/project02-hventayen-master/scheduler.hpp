#ifndef _SCHEDULER_HPP_
#define _SCHEDULER_HPP_
#include <iostream>
#include <string>
const int TEN = 10;
const int HUN = 100;
class Course
{
  // Private variables
private:
  std::string course_name_;
  std::string location_;
  std::string weekly_schedule_;
  int start_time_;
  int end_time_;
  // std::string start_string_;
  // std::string end_string_;
  // Public variables
public:
  void set_course_name(std::string const & c) { course_name_ = c; }
  void set_location(std::string const & l) { location_ = l; }
  void set_weekly_schedule(std::string const & w) { weekly_schedule_ = w; }
  void set_start_time(int s) { start_time_ = s; }
  void set_end_time(int e) { end_time_ = e; }
  // void set_start_string(std::string ss) { start_string_ = ss; }
  // void set_end_string(std::string es) { end_string_ = es; }
  std::string course_name() const { return course_name_; }
  std::string location() const { return location_; }
  std::string weekly_schedule() const { return weekly_schedule_; }
  int start_time() const { return start_time_; }
  int end_time() const { return end_time_; }
  // Displays the information of the schedule
  // Add member functions
  void display()
  {
    int startHour = (start_time_ / HUN);
    int startMin = (start_time_ % HUN);
    int hour = (end_time_ / HUN);
    int minutes = end_time_ % HUN;
    std::cout << "Course name: " << course_name_ << std::endl;
    std::cout << "Location: " << location_ << std::endl;
    std::cout << "Weekly schedule: " << weekly_schedule_ << std::endl;
    std::cout << "Start time: " << startHour << ":"
              << (startMin < TEN ? "0" : "") << startMin << std::endl;
    std::cout << "End time: " << hour << ":" << (minutes < TEN ? "0" : "")
              << minutes << "\n";
  }
};

bool load_schedule(std::string const & myFile, Course array[], int & size);
void display_courses(Course array[], int size);

#endif
