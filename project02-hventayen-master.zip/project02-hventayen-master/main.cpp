#include <iostream>
#include <string>
#include "scheduler.hpp"

int main()
{
  // Make an array
  const int OBJECTS = 100;
  int arraySize = 0;
  Course array[OBJECTS];
  std::string myFile;
  std::cout << "Welcome to Tuffy Scheduler!" << std::endl;
  std::cout << "Please enter the file name containing the list of classes: ";
  std::cin >> myFile;
  // If the whole schedule was loaded, it shows contents of schedule
  if (load_schedule(myFile, array, arraySize))
  {
    display_courses(array, arraySize);
  }
  else
  {
  }
  std::cout << "Thank you so much for using Tuffy Scheduler." << std::endl;
  return 0;
}
