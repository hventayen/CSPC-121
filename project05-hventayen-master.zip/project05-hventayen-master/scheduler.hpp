#ifndef _SCHEDULER_HPP_
#define _SCHEDULER_HPP_
#include <iostream>
#include <string>
const int TEN = 10;
const int HUN = 100;
// Time is more complicated so we need to display it in a specific way
class TimeSpan
{
  // Private variables
private:
  int start_time_;
  int end_time_;
  // Public variables
public:
  TimeSpan() : start_time_(0000), end_time_(0000) {}
  TimeSpan(int s, int e) : start_time_(s), end_time_(e) {}
  void set_start_time(int s) { start_time_ = s; }
  void set_end_time(int e) { end_time_ = e; }
  int start_time() const { return start_time_; }
  int end_time() const { return end_time_; }
  // Operator overload prototypes
  bool operator<(const TimeSpan & time);
  bool operator>(const TimeSpan & time);
  void display()
  {
    // Used to divide the start and end times for later comparison
    int start1 = start_time_ / 100;
    int start2 = start_time_ % 100;
    int end1 = end_time_ / 100;
    int end2 = end_time_ % 100;
    // Minutes might be less than or more than 10, which requires specific cases
    // to be checked
    if ((end2 < 10) && (start2 < 10))
    {
      std::cout << "Start time: " << start1 << ":0" << start2 << std::endl
                << "End time: " << end1 << ":0" << end2 << std::endl;
    }
    else if (end2 < 10)
    {
      std::cout << "Start time: " << start1 << ":" << start2 << std::endl
                << "End time: " << end1 << ":0" << end2 << std::endl;
    }
    else if (start2 < 10)
    {
      std::cout << "Start time: " << start1 << ":0" << start2 << std::endl
                << "End time: " << end1 << ":" << end2 << std::endl;
    }
    else
    {
      std::cout << "Start time: " << start1 << ":" << start2 << std::endl
                << "End time: " << end1 << ":" << end2 << std::endl;
    }
  }
};
// This class stores info of a single course, making it easier for classes to
// access course info, switching every time a new course is asking to be put in
// the schedule
class Course
{
  // Private variables
private:
  std::string course_name_;
  std::string location_;
  std::string weekly_schedule_;
  TimeSpan time_;
  // Public variables
public:
  Course() : course_name_(""), location_(""), weekly_schedule_("") {}
  Course(const std::string & c, const std::string & l, const std::string & w,
         const TimeSpan & t)
      : course_name_(c), location_(l), weekly_schedule_(w), time_(t)
  {
  }
  void set_course_name(std::string const & c) { course_name_ = c; }
  void set_location(std::string const & l) { location_ = l; }
  void set_weekly_schedule(std::string const & w) { weekly_schedule_ = w; }
  void set_time(const TimeSpan & t) { time_ = t; }
  std::string course_name() const { return course_name_; }
  std::string location() const { return location_; }
  std::string weekly_schedule() const { return weekly_schedule_; }
  TimeSpan time() const { return time_; }
  // Displays the information of the single course
  void display()
  {
    std::cout << "Course name: " << course_name_ << std::endl;
    std::cout << "Location: " << location_ << std::endl;
    std::cout << "Weekly schedule: " << weekly_schedule_ << std::endl;
    time_.display();
  }
  // Checks if the last course intersects with the current course
  bool intersects(Course * cptr)
  {
    int weeklySize = weekly_schedule_.size();
    int cptrSize = cptr->weekly_schedule().size();
    for (int i = 0; i < weeklySize; i++)
    {
      for (int j = 0; j < cptrSize; j++)
      {
        if (weekly_schedule_.at(i) == cptr->weekly_schedule().at(j))
        {
          if (!(time_ < cptr->time() || time_ > cptr->time()))
          {
            return true;
          }
        }
      }
    }
    return false;
  }
};
// Checks if the course asking to be put in intersects with the last class and
// adds it to the schedule if it has conflicts
class CourseSchedule
{
private:
  Course * courses_[100];
  int num_courses_;
  bool has_conflict(Course * cptr)
  {
    // Checks with all courses each time to see if they have a problem
    for (int i = 0; i < num_courses_; i++)
    {
      // Checks if proposed course object intersects with a time
      if (courses_[i]->intersects(cptr))
      {
        return true;
      }
    }
    return false;
  }

public:
  CourseSchedule() : num_courses_(0) {}
  int num_courses() { return num_courses_; }
  // Checks if object is an object with no conflicts then adds it to the list of
  // courses, and if it has conflicts it throws it away then checks a new course
  bool add(const std::string & c, const std::string & l, const std::string & w,
           int s, int e)
  {
    // Dynamically allocate a course object in the heap for later testing if it
    // has conflicts
    courses_[num_courses_] = new Course(c, l, w, TimeSpan(s, e));
    if (!has_conflict(courses_[num_courses_]))
    {
      num_courses_++;
      return true;
    }
    delete courses_[num_courses_];
    return false;
  }

  // Displays the details of all the course objects
  void display()
  {
    // Loops through all of the existing courses
    for (int i = 0; i < num_courses_; i++)
    {
      std::cout << "Course name: " << courses_[i]->course_name() << std::endl
                << "Location: " << courses_[i]->location() << std::endl
                << "Weekly schedule: " << courses_[i]->weekly_schedule()
                << std::endl;
      courses_[i]->display();
    }
  }
  // Deallocate all course objects
  ~CourseSchedule()
  {
    for (int i = 0; i < num_courses_; i++)
    {
      delete courses_[i];
    }
  }
};
bool load_schedule(const std::string & myFile, CourseSchedule & course);
#endif
