# Description
Describe your program in your own words.
My program takes course information and organizes it in a class schedule. It takes the object, check if it has conflicts with any other course added before it then adds it. It also throws away courses that has conflicts as well.
# Challenges encountered
Describe the challenges you encountered while creating your program.
It was a real challenge looking at how the pointers in the array would be passed around in the classes. Checking if they intersect or has conflicts was a real struggle as well since we have to check a wide range of cases.
# Things I've learned
What is the most important thing you've learned from creating your program?
The most important thing i've learned was how we can make an array of pointer objects that have information assigned to it. I also learned how they interact with other classes and how the overridden display functions can be called through calling them with variables of different classes.
