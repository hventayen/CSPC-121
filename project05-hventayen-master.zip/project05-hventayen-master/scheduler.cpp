#include <iostream>
#include <string>
#include "scheduler.hpp"
#include <fstream>
#include <sstream>
#include <cmath>
// Checks if the course is valid, if so, it adds it to course schedule
bool load_schedule(std::string const & myFile, CourseSchedule & course)
{
  const int HOURS = 23;
  const int MIN = 59;
  const int FIVE = 5;
  std::string word;
  std::string fullStart;
  std::string fullEnd;
  std::string wordCourse;
  std::string wordLocation;
  std::string wordWeekly;
  int numStart;
  int numEnd;
  int startHour;
  int startMin;
  int endHour;
  int endMin;
  int count = 1;
  int errorCount = 0;
  std::ifstream schedule;
  schedule.open(myFile);
  if (schedule)
  {
    // Checks each and every entry
    while (getline(schedule, word) && errorCount == 0)
    {
      if (count == 1)
      {
        // Point to one object and then set it to the next element
        CourseSchedule * course = new CourseSchedule;
        // Used for the add function to assign to object
        wordCourse = word;
        delete course;
      }

      if (count == 2 && word.empty())
      {
        std::cout << "Error: Unable to get a location.";
        errorCount++;
        break;
      }

      if (count == 2)
      {
        // Used for the add function to assign to object
        wordLocation = word;
      }

      if (count == 3 && word.empty())
      {
        std::cout << "Error: Unable to retrieve a weekly schedule."
                  << std::endl;
        errorCount++;
        break;
      }
      if (count == 3)
      {
        if (word.length() > 0)
        {
          if (word != "M" && word != "T" && word != "W" && word != "H" &&
              word != "F" && word != "S" && word != "MW" && word != "MF" &&
              word != "TH")
          {
            std::cout << "Error, weekly schedule symbol " << word << ".\n";
            errorCount++;
            break;
          }
        }
        // Used for the add function to assign to object
        wordWeekly = word;
      }

      if (count == 4 && word.empty())
      {
        std::cout << "Error: Unable to get a valid start time.";
        errorCount++;
        break;
      }
      if (count == 4)
      {
        fullStart = word;
        char colon = ' ';
        std::stringstream ss(word);
        ss >> startHour >> colon >> startMin;
        if (colon != ':')
        {
          std::cout << "Error: Unable to get a valid start time";
          errorCount++;
          break;
        }
        if (startHour >= 0 && startHour <= HOURS)
        {
          if (startMin >= 0 && startMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: Unable to use " << word << " as start time."
                      << std::endl;
            errorCount++;
            break;
          }
        }
        else
        {
          std::cout << "Error: Unable to use " << word << " as start time."
                    << std::endl;
          errorCount++;
          break;
        }
        // Used for the add function to assign to object
        numStart = (startHour * HUN) + startMin;
      }

      if (count == FIVE && word.empty())
      {
        std::cout << "Error: Unable to get a valid end time.";
        errorCount++;
        break;
      }
      if (count == FIVE)
      {
        fullEnd = word;
        char colon2 = ' ';
        std::stringstream ww(word);
        ww >> endHour >> colon2 >> endMin;
        if (colon2 != ':')
        {
          std::cout << "Error: Unable to gather end time.";
          errorCount++;
          break;
        }
        if (endHour >= 0 && endHour <= HOURS)
        {
          if (endMin >= 0 && endMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: " << word
                      << " is unable to be used as a valid end time."
                      << std::endl;
            errorCount++;
          }
        }
        else
        {
          std::cout << "Error: " << word
                    << " is unable to be used as a valid end time."
                    << std::endl;
          errorCount++;
          break;
        }

        if (startHour > endHour || (startHour == endHour && startMin > endMin))
        {
          if (startMin != endMin)
          {
            std::cout << "Error: The start time " << fullStart
                      << " should happen before the end time " << fullEnd << "."
                      << std::endl;
            break;
          }
        }
        // Used for the add function to assign to object
        numEnd = (endHour * HUN) + endMin;
        count = 0;
        // Adds all the details to make a new course object
        if (course.add(wordCourse, wordLocation, wordWeekly, numStart, numEnd))
        {
        }
      }
      count++;
    }
    // While loop ends here
    // Makes sure an an error is counted for all cases
    if (count == 2)
    {
      std::cout << "Error: Unable to get location." << std::endl;
      errorCount++;
    }
    else if (count == 3 && errorCount == 0)
    {
      std::cout << "Error: Unable to get a weekly schedule." << std::endl;
      errorCount++;
    }
    else if (count == 4)
    {
      std::cout << "Error: Unable to get a valid start time." << std::endl;
      errorCount++;
    }
    else if (count == FIVE)
    {
      std::cout << "Error: Unable to get a valid end time." << std::endl;
      errorCount++;
    }
    else if (errorCount == 0)
    {
      std::cout << "Valid file!" << std::endl;
    }
    schedule.close();
  }
  else
  {
    std::cout << "Error: The file does not exist. Invalid file." << std::endl;
    errorCount++;
  }
  if (errorCount > 0)
  {
    std::cout << "Invalid file." << std::endl;
    return false;
  }
  return true;
}
// Operator functions
// Check if last timespan comepletely less than new timespan
bool TimeSpan::operator<(const TimeSpan & time)
{
  return (end_time_ < time.start_time());
}
// Check if last timespan comepletely more than new timespan
bool TimeSpan::operator>(const TimeSpan & time)
{
  return (start_time_ > time.end_time());
}
