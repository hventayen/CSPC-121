#include <iostream>

int main() {
  int length, width;
  std::cout << "Please enter the length: ";
  std::cin >> length;
  std::cout << "Please enter the width: ";
  std::cin >> width;
  // Add the code here to call the appropriate functions
  // and  display the correctly formatted output on the
  // screen.
  return 0;
}
