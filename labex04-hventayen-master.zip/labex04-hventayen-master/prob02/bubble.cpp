#include "bubble.hpp"
#include <cmath>

// Make volume function, Bubble:: connects it to bubble class
double Bubble::volume() const
{
  double val;
  const double num = 4.0 / 3.0;
  const double pi = 3.1415;
  val = num * pi * pow(_radius, 3);
  return val;
}
// Adds two objects together
Bubble Bubble::operator+(const Bubble & bubble)
{
  Bubble bubble3;
  double val = _radius + bubble.radius();
  bubble3.set_radius(val);
  return bubble3;
}
// Checks if two objects are equal
bool Bubble::operator==(const Bubble & bubble3)
{
  return (_radius == bubble3.radius());
}
