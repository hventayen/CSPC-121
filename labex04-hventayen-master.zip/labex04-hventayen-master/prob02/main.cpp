#include "bubble.hpp"
#include <cmath>
#include <iomanip>
#include <iostream>

int main()
{
  // TODO: create two Bubble objects called bubble1 and bubble2
  Bubble bubble1;
  Bubble bubble2;
  Bubble combined;
  double radius1;
  double radius2;
  double radius3;
  // get the radius of both bubbles from the user
  std::cout << "Please enter the radius of the first bubble: ";
  std::cin >> radius1;
  std::cout << "Please enter the radius of the second bubble: ";
  std::cin >> radius2;

  // TODO: set the radius of bubble1 to radius1 and bubble2 to radius2
  // Set the radius of bubble1 to radius1
  bubble1.set_radius(radius1);
  // Set the radius of bubble2 to radius2
  bubble2.set_radius(radius2);
  combined.set_radius(radius3);
  // TODO: use the overloaded operator== function to determine whether
  // bubble1 and bubble2 are the same size
  // Call boolean overload function
  if (bubble1 == bubble2)
  {
    std::cout << "Your bubbles are the same size.\n";
  }

  // TODO: create a new Bubble object called combined, and call the
  // overloaded operator+ function to combine bubble1 and bubble2
  // Call addition overload function
  combined = bubble1 + bubble2;
  // TODO: get the volume of the combined Bubble object and print it out
  double volume;
  volume = combined.volume();
  std::cout << "The bubbles have now combined and created a bubble with the "
            << "volume of: " << volume << std::endl;

  return 0;
}
