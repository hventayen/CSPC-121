// Must define with this exact format
#ifndef _BUBBLE_HPP_
#define _BUBBLE_HPP_
// Connects main.cpp and bubble.cpp
class Bubble
{

private:
  double _radius;

public:
  // Set radius for an object
  void set_radius(double r) { _radius = r; };
  // Makes new object _radius
  double radius() const { return _radius; };
  // Prototype for volume function
  double volume() const;
  // Prototype overloader adding
  Bubble operator+(const Bubble & right);
  // Prototype overloader boolean
  bool operator==(const Bubble & right);
};
// Must add prototype
Bubble combine_bubble(Bubble radius1, Bubble radius2);
// End
#endif
