#include "bubble.hpp"
#include <cmath>
// Refers to the bubble class
Bubble combine_bubble(Bubble radius1, Bubble radius2)
{
  Bubble b;
  double rad;
  // Dealing with the objects of bubble type
  rad = radius1.radius() + radius2.radius();
  b.set_radius(rad);
  return b;
}
// Make volume function, Bubble:: connects it to bubble class
double Bubble::volume() const
{
  double val;
  const double num = 4.0 / 3.0;
  const double pi = 3.1415;
  val = num * pi * pow(_radius, 3);
  return val;
}
