#include <fstream>
#include <iostream>
int main()
{
  std::ofstream out_file;
  std::string fileName;
  int donors;
  double num;
  std::cout << "Please provide the number of donors: ";
  std::cin >> donors;
  // Decide if you have at least one donor
  if (donors > 0)
  {
    std::cout << "Please provide the name of the donations file: ";
    std::cin >> fileName;
    // Makes file if one is not made
    out_file.open(fileName);
    // Input donors
    out_file << donors << std::endl;
    for (int i = 1; i < donors + 1; i++)
    {
      std::cout << "Donor " << i << ": $";
      std::cin >> num;
      out_file << num << std::endl;
    }
    std::cout << "Thank you for donating!" << std::endl;
  }
  // If there are no donors
  else
  {
    std::cout << "You need to have at least one donor for your cause to save "
              << "donation information.";
  }
  // Close file
  out_file.close();
  return 0;
}
