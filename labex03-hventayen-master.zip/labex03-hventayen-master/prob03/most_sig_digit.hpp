// Prototype, basically connects both files to each other
int most_significant_digit(int num);
