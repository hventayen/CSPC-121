#include <iostream>
#include "most_sig_digit.hpp"
// Header for the function
int most_significant_digit(int num)
{
  while (num > 9 || num < -9)
  {
    num /= 10;
  }
  return num;
}
