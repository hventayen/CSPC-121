#include <fstream>
#include <iostream>
int main()
{
  int months = 0;
  int reportNumber = 1;
  double sum = 0;
  double sales;
  std::string fileName;
  std::ifstream in_file;
  std::cout << "Please provide the file name for your report file: ";
  std::cin >> fileName;
  // Check if the report file has the right name
  in_file.open(fileName);
  if (in_file)
  {
    std::cout << "Please provide the number of months to be consolidated: ";
    std::cin >> months;
    std::cout << std::endl;
    // Must be 1 or more months to work
    if (months >= 1)
    {
      // Loops so that we keep getting a value from report.txt
      while (in_file >> sales)
      {
        // Saves value so you can print sum every 1,2,3 months
        sum = sum + sales;
        if (reportNumber % months == 0)
        {
          std::cout << "Month ";
          // For when months gets bigger than 1
          for (int i = 1; i <= months; i++)
          {
            // Adds month number to output
            std::cout << reportNumber - months + i << " ";
          }
          std::cout << "sales: $" << sum << std::endl;
          // Set sum to 0 so you can just sum the number of months you want
          sum = 0;
        }
        reportNumber++;
      }
    }
    else
    {
      std::cout << "You need at least one month to consolidate." << std::endl;
    }
  }
  else
  {
    std::cout << "Invalid report file!" << std::endl;
  }
  // Must close file
  in_file.close();
}
