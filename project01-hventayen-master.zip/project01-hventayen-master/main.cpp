#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
const int HOURS = 23;
const int MIN = 59;
const int MAGIC = 5;
int main()
{
  std::string myFile;
  std::string word;
  std::string fullStart;
  std::string fullEnd;
  int startHour;
  int startMin;
  int endHour;
  int endMin;
  int count = 1;
  int errorCount = 0;
  std::cout << "Welcome to Tuffy Scheduler!" << std::endl;
  std::cout << "Please enter the file name containing the list of classes: "
            << std::endl;
  std::cin >> myFile;

  std::ifstream schedule;
  schedule.open(myFile);
  if (schedule)
  {
    while (getline(schedule, word) && errorCount == 0)
    {
      std::cout << count << word << std::endl;
      if (count == 2 && word.empty())
      {
        std::cout << "Error: Unable to get a location." << std::endl;
        errorCount++;
        break;
      }
      if (count == 3 && word.empty())
      {
        std::cout << "Error: Unable to retrieve a weekly schedule."
                  << std::endl;
        errorCount++;
        break;
      }
      if (count == 3)
      {
        if (word.length() > 0)
        {
          if (word != "M" && word != "T" && word != "W" && word != "H" &&
              word != "F" && word != "S" && word != "MW" && word != "MF" &&
              word != "TH")
          {
            std::cout << "Error, weekly schedule symbol error." << word
                      << ". Invalid file" << std::endl;
            errorCount++;
            break;
          }
        }
      }
      if (count == 4 && word.empty())
      {
        std::cout << "Error: Unable to get a valid start time." << std::endl;
        errorCount++;
        break;
      }
      if (count == 4)
      {
        fullStart = word;

        char colon = ' ';
        std::stringstream ss(word);
        ss >> startHour >> colon >> startMin;
        if (colon != ':')
        {
          std::cout << "Error: Unable to get an invalid start time";
          errorCount++;
          break;
        }

        if (startHour >= 0 && startHour <= HOURS)
        {
          if (startMin >= 0 && startMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: Unable " << word
                      << " to be used as an invalid start time." << std::endl;
            errorCount++;
            break;
          }
        }
        else
        {
          std::cout << "Error: Unable " << word
                    << " to be used as an invalid start time." << std::endl;
          errorCount++;
          break;
        }
      }
      if (count == MAGIC && word.empty())
      {
        std::cout << "Error: Unable to get a valid end time." << std::endl;
        errorCount++;
        break;
      }
      if (count == MAGIC)
      {
        fullEnd = word;
        char colon2 = ' ';
        std::stringstream ww(word);
        ww >> endHour >> colon2 >> endMin;
        if (colon2 != ':')
        {
          std::cout << "Error: Unable to get an invalid end time.";
          errorCount++;
          break;
        }
        if (endHour >= 0 && endHour <= HOURS)
        {
          if (endMin >= 0 && endMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: " << word
                      << " is unable to be used as a valid end time."
                      << std::endl;
            errorCount++;
            break;
          }
        }
        else
        {
          std::cout << "Error: " << word
                    << " is unable to be used as a valid end time."
                    << std::endl;
          errorCount++;
          break;
        }

        if (startHour > endHour || (startHour == endHour && startMin > endMin))
        {
          std::cout << "Error: The start time " << fullStart
                    << " should happen before the end time " << fullEnd << "."
                    << std::endl;
          errorCount++;
          break;
        }
        count = 0;
      }

      count++;
    }
    // While loop ends here
    if (count == 2)
    {
      std::cout << "Error: Unable to get location." << std::endl;
      errorCount++;
    }
    else if (count == 3)
    {
      std::cout << "Error: Unable to get weekly schedule." << std::endl;
      errorCount++;
    }
    else if (count == 4)
    {
      std::cout << "Error: Unable to get start time." << std::endl;
      errorCount++;
    }
    else if (count == 0)
    {
      std::cout << "Error: Unable to get end time." << std::endl;
      errorCount++;
    }
    else if (errorCount == 0)
    {
      std::cout << "Valid file" << std::endl;
    }

    schedule.close();
  }
  else
  {
    std::cout << "Error: The file does not exist." << std::endl;
    errorCount++;
  }
  if (errorCount > 0)
  {
    std::cout << "Invalid file." << std::endl;
  }
  std::cout << "Thank you for using Tuffy Scheduler." << std::endl;
  return 0;
}

/*
Description
The program gets a .txt file and then gets the items from there, making sure
that the schedule is valid. The program has a counter to make sure
it is checking errors for the right course, location, or day.

Challenges encountered
Dealing with the counter and figuring out how it was gonna keep looping
was hard. Not to mention how we were gonna convert strings into ints and
interact with them. There were many silly mistakes I made which I had to figure
out, making the whole code not work.

Things i've learned
I have learned to convert strings to ints, and learned to use simple counting
systems to make a schedule. I learned to check all the bugs of my program and
how one error can mess everything up
*/
