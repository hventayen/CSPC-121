#include "scheduler.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cmath>
void TimeSpan::display()
{
  // Used to divide the start and end times for later comparison
  int start1 = start_time_ / HUN;
  int start2 = start_time_ % HUN;
  int end1 = end_time_ / HUN;
  int end2 = end_time_ % HUN;
  // Minutes might be less than or more than 10, which requires specific cases
  // to be checked
  if ((end2 < TEN) && (start2 < TEN))
  {
    std::cout << "Start time: " << start1 << ":0" << start2 << std::endl
              << "End time: " << end1 << ":0" << end2 << std::endl;
  }
  else if (end2 < TEN)
  {
    std::cout << "Start time: " << start1 << ":" << start2 << std::endl
              << "End time: " << end1 << ":0" << end2 << std::endl;
  }
  else if (start2 < TEN)
  {
    std::cout << "Start time: " << start1 << ":0" << start2 << std::endl
              << "End time: " << end1 << ":" << end2 << std::endl;
  }
  else
  {
    std::cout << "Start time: " << start1 << ":" << start2 << std::endl
              << "End time: " << end1 << ":" << end2 << std::endl;
  }
}
void Course::display()
{
  std::cout << "Course name: " << course_name_ << std::endl;
  std::cout << "Location: " << location_ << std::endl;
  std::cout << "Weekly schedule: " << weekly_schedule_ << std::endl;
  time_.display();
}
bool Course::intersects(Course * cptr)
{
  int weeklySize = weekly_schedule_.size();
  int cptrSize = cptr->weekly_schedule().size();
  for (int i = 0; i < weeklySize; i++)
  {
    for (int j = 0; j < cptrSize; j++)
    {
      if (weekly_schedule_.at(i) == cptr->weekly_schedule().at(j))
      {
        if (!(time_ < cptr->time() || time_ > cptr->time()))
        {
          return true;
        }
      }
    }
  }
  return false;
}
bool CourseSchedule::has_conflict(Course * cptr)
{
  // Checks with all courses each time to see if they have a problem
  for (int i = 0; i < num_courses_; i++)
  {
    // Checks if proposed course object intersects with a time
    if (courses_[i]->intersects(cptr))
    {
      return true;
    }
  }
  return false;
}
bool CourseSchedule::add(const std::string & c, const std::string & l,
                         const std::string & w, int s, int e)
{
  // Dynamically allocate a course object in the heap for later testing if it
  // has conflicts
  if (remove_conflicts_)
  {
    courses_[num_courses_] = new Course(c, l, w, TimeSpan(s, e));
    if (!has_conflict(courses_[num_courses_]))
    {
      num_courses_++;
      return true;
    }
    delete courses_[num_courses_];
    return false;
  }
  courses_[num_courses_] = new Course(c, l, w, TimeSpan(s, e));
  num_courses_++;
  return true;
}
bool CourseSchedule::add(Course * cptr)
{
  std::string c = cptr->course_name();
  std::string l = cptr->location();
  std::string w = cptr->weekly_schedule();
  int s = cptr->time().start_time();
  int e = cptr->time().end_time();
  return add(c, l, w, s, e);
}
void CourseSchedule::display()
{
  // Loops through all of the existing courses
  for (int i = 0; i < num_courses_; i++)
  {
    std::cout << "Course name: " << courses_[i]->course_name() << std::endl
              << "Location: " << courses_[i]->location() << std::endl
              << "Weekly schedule: " << courses_[i]->weekly_schedule()
              << std::endl;
    courses_[i]->display();
  }
}
CourseSchedule::~CourseSchedule()
{
  for (int i = 0; i < num_courses_; i++)
  {
    delete courses_[i];
  }
}
// Checks if the course is valid, if so, it adds it to course schedule
bool ScheduleManager::load_schedule(std::string const & myFile)
{
  std::string word;
  std::string fullStart;
  std::string fullEnd;
  std::string wordCourse;
  std::string wordLocation;
  std::string wordWeekly;
  int numStart;
  int numEnd;
  int startHour;
  int startMin;
  int endHour;
  int endMin;
  int count = 1;
  int errorCount = 0;
  std::ifstream schedule;
  schedule.open(myFile);
  if (schedule)
  {
    // Checks each and every entry
    while (getline(schedule, word) && errorCount == 0)
    {
      if (count == 1)
      {
        // Point to one object and then set it to the next element
        // CourseSchedule * course = new CourseSchedule;
        // Used for the add function to assign to object
        wordCourse = word;
        // delete course;
      }

      if (count == 2 && word.empty())
      {
        std::cout << "Error: Unable to get a location.";
        errorCount++;
        break;
      }

      if (count == 2)
      {
        // Used for the add function to assign to object
        wordLocation = word;
      }

      if (count == 3 && word.empty())
      {
        std::cout << "Error: Unable to retrieve a weekly schedule."
                  << std::endl;
        errorCount++;
        break;
      }
      if (count == 3)
      {
        if (word.length() > 0)
        {
          if (word != "M" && word != "T" && word != "W" && word != "H" &&
              word != "F" && word != "S" && word != "MW" && word != "MF" &&
              word != "TH")
          {
            std::cout << "Error, weekly schedule symbol " << word << ".\n";
            errorCount++;
            break;
          }
        }
        // Used for the add function to assign to object
        wordWeekly = word;
      }

      if (count == 4 && word.empty())
      {
        std::cout << "Error: Unable to get a valid start time.";
        errorCount++;
        break;
      }
      if (count == 4)
      {
        fullStart = word;
        char colon = ' ';
        std::stringstream ss(word);
        ss >> startHour >> colon >> startMin;
        if (colon != ':')
        {
          std::cout << "Error: Unable to get a valid start time";
          errorCount++;
          break;
        }
        if (startHour >= 0 && startHour <= HOURS)
        {
          if (startMin >= 0 && startMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: Unable to use " << word << " as start time."
                      << std::endl;
            errorCount++;
            break;
          }
        }
        else
        {
          std::cout << "Error: Unable to use " << word << " as start time."
                    << std::endl;
          errorCount++;
          break;
        }
        // Used for the add function to assign to object
        numStart = (startHour * HUN) + startMin;
      }

      if (count == FIVE && word.empty())
      {
        std::cout << "Error: Unable to get a valid end time.";
        errorCount++;
        break;
      }
      if (count == FIVE)
      {
        fullEnd = word;
        char colon2 = ' ';
        std::stringstream ww(word);
        ww >> endHour >> colon2 >> endMin;
        if (colon2 != ':')
        {
          std::cout << "Error: Unable to gather end time.";
          errorCount++;
          break;
        }
        if (endHour >= 0 && endHour <= HOURS)
        {
          if (endMin >= 0 && endMin <= MIN)
          {
          }
          else
          {
            std::cout << "Error: " << word
                      << " is unable to be used as a valid end time."
                      << std::endl;
            errorCount++;
          }
        }
        else
        {
          std::cout << "Error: " << word
                    << " is unable to be used as a valid end time."
                    << std::endl;
          errorCount++;
          break;
        }

        if (startHour > endHour || (startHour == endHour && startMin > endMin))
        {
          if (startMin != endMin)
          {
            std::cout << "Error: The start time " << fullStart
                      << " should happen before the end time " << fullEnd << "."
                      << std::endl;
            break;
          }
        }
        // Used for the add function to assign to object
        numEnd = (endHour * HUN) + endMin;
        count = 0;
        // Adds all the details to make a new course object
        if (complete_schedule_.add(wordCourse, wordLocation, wordWeekly,
                                   numStart, numEnd))
        {
        }
      }
      count++;
    }
    // While loop ends here
    // Makes sure an an error is counted for all cases
    if (count == 2)
    {
      std::cout << "Error: Unable to get location." << std::endl;
      errorCount++;
    }
    else if (count == 3 && errorCount == 0)
    {
      std::cout << "Error: Unable to get a weekly schedule." << std::endl;
      errorCount++;
    }
    else if (count == 4)
    {
      std::cout << "Error: Unable to get a valid start time." << std::endl;
      errorCount++;
    }
    else if (count == FIVE)
    {
      std::cout << "Error: Unable to get a valid end time." << std::endl;
      errorCount++;
    }
    else if (errorCount == 0)
    {
      std::cout << "Valid file!" << std::endl;
    }
    schedule.close();
  }
  else
  {
    std::cout << "Error: The file does not exist. Invalid file." << std::endl;
    errorCount++;
  }
  if (errorCount > 0)
  {
    std::cout << "Invalid file." << std::endl;
    return false;
  }
  return true;
}
// Picks the best schedule
CourseSchedule * ScheduleManager::best_schedule(const std::string & myFile)
{
  int best_schedule_count = 0;
  if (load_schedule(myFile))
  {
    int courseCount = complete_schedule_.num_courses();
    // Copies all the course objects for comparison
    Course * course[complete_schedule_.num_courses()];
    for (int i = 0; i < complete_schedule_.num_courses(); i++)
    {
      course[i] = complete_schedule_.course(i);
    }
    do
    {
      // Make temp to compare other possible schedules with other schedules
      CourseSchedule * temp = new CourseSchedule;
      for (int i = 0; i < complete_schedule_.num_courses(); i++)
      {
        temp->add(course[i]);
      }
      // Debug so the first iteration of loop isnt null
      if (best_schedule_ != nullptr)
      {
        best_schedule_count = best_schedule_->num_courses();
      }
      // Compares the amount of courses in both schedules
      if (best_schedule_count < temp->num_courses())
      {
        delete best_schedule_;
        best_schedule_ = temp;
      }
      else
      {
        delete temp;
        temp = nullptr;
      }
      best_schedule_count++;
      // Loop keeps checking possible combos
    } while (std::next_permutation(course, course + courseCount));
  }
  else
  {
    return nullptr;
  }
  return best_schedule_;
}
// Operator
bool TimeSpan::operator<(const TimeSpan & time)
{
  return (end_time_ < time.start_time());
}
// Operator
bool TimeSpan::operator>(const TimeSpan & time)
{
  return (start_time_ > time.end_time());
}
