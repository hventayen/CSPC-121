# Description
Describe your program in your own words.
My program takes students' information and makes them into courses, which go into a schedule. This schedule is then compared to other schedules in order to get the best schedule with the most courses put into it. The program contains a lot of pointers, and work with permutations that can check all the possible outcomes of a schedule in order to determine the schedule with the most courses.
# Challenges encountered
Describe the challenges you encountered while creating your program.
Challenges were that it was very hard to get used to working with permutations, and it was difficult to somehow make it so that the pointers didn't have a memory leak. Overall there were many cases where I found problems with my program where my code would fail from little mistakes.
# Things I've learned
What is the most important thing you've learned from creating your program?
I learned how important it is to look over your code and track code so that there are no memory leaks. The simplest mistake can mees up my whole code and it is very hard to find. It is better to make your code as efficient as possible so that others can look at your code and it can be easy to track to solve the problem.
