#include <iostream>
#include <string>
#include "scheduler.hpp"

int main()
{
  int arraySize = 0;
  // Make a pointer to make a bunch of objects
  ScheduleManager schedule;
  CourseSchedule * course;
  std::string myFile;
  std::cout << "Welcome to Tuffy Scheduler!" << std::endl;
  std::cout << "Please enter the file name containing the list of classes: ";
  std::cin >> myFile;
  course = schedule.best_schedule(myFile);
  // If the whole schedule was loaded, it shows contents of schedule
  if (course != nullptr)
  {
    // Displays all the information
    course->display();
  }
  else
  {
  }
  std::cout << "Thank you so much for using Tuffy Scheduler." << std::endl;
  return 0;
}
