#ifndef _SCHEDULER_HPP_
#define _SCHEDULER_HPP_
#include <algorithm>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cmath>
const int TEN = 10;
const int HUN = 100;
const int HOURS = 23;
const int MIN = 59;
const int FIVE = 5;
// Time is more complicated so we need to display it in a specific way
class TimeSpan
{
  // Private variables
private:
  int start_time_;
  int end_time_;
  // Public variables
public:
  TimeSpan() : start_time_(0000), end_time_(0000) {}
  TimeSpan(int s, int e) : start_time_(s), end_time_(e) {}
  void set_start_time(int s) { start_time_ = s; }
  void set_end_time(int e) { end_time_ = e; }
  int start_time() const { return start_time_; }
  int end_time() const { return end_time_; }
  // Operator functions
  // Check if last timespan comepletely less than new timespan
  bool operator<(const TimeSpan & time);
  // Check if last timespan comepletely more than new timespan
  bool operator>(const TimeSpan & time);
  void display();
};
// This class stores info of a single course, making it easier for classes to
// access course info, switching every time a new course is asking to be put in
// the schedule
class Course
{
  // Private variables
private:
  std::string course_name_;
  std::string location_;
  std::string weekly_schedule_;
  TimeSpan time_;
  // Public variables
public:
  Course() : course_name_(""), location_(""), weekly_schedule_("") {}
  Course(const std::string & c, const std::string & l, const std::string & w,
         const TimeSpan & t)
      : course_name_(c), location_(l), weekly_schedule_(w), time_(t)
  {
  }
  void set_course_name(std::string const & c) { course_name_ = c; }
  void set_location(std::string const & l) { location_ = l; }
  void set_weekly_schedule(std::string const & w) { weekly_schedule_ = w; }
  void set_time(const TimeSpan & t) { time_ = t; }
  std::string course_name() const { return course_name_; }
  std::string location() const { return location_; }
  std::string weekly_schedule() const { return weekly_schedule_; }
  TimeSpan time() const { return time_; }
  // Displays the information of the single course
  void display();
  // Checks if the last course intersects with the current course
  bool intersects(Course * cptr);
};
// Checks if the course asking to be put in intersects with the last class and
// adds it to the schedule if it has conflicts
class CourseSchedule
{
private:
  Course * courses_[HUN];
  int num_courses_;
  bool remove_conflicts_;
  bool has_conflict(Course * cptr);

public:
  CourseSchedule() : CourseSchedule(true) {}
  CourseSchedule(bool c) : num_courses_(0), remove_conflicts_(c) {}
  int num_courses() { return num_courses_; }
  // Checks if object is an object with no conflicts then adds it to the list of
  // courses, and if it has conflicts it throws it away then checks a new course
  bool add(const std::string & c, const std::string & l, const std::string & w,
           int s, int e);

  bool add(Course * cptr);

  Course * course(int ix) { return courses_[ix]; }

  // Displays the details of all the course objects
  void display();
  // Deallocate all course objects
  ~CourseSchedule();
};

class ScheduleManager
{
private:
  // Contains all the Course objects from the file
  CourseSchedule complete_schedule_;
  // Contains the address of the best schedule
  CourseSchedule * best_schedule_;
  bool load_schedule(std::string const & myFile);

public:
  // Constructors
  ScheduleManager()
      : complete_schedule_(CourseSchedule(false)), best_schedule_(nullptr)
  {
  }
  CourseSchedule * best_schedule(const std::string & myFile);
  // Helps for pointers to delete when outside of this class
  ~ScheduleManager() { delete best_schedule_; }
};
#endif
