#ifndef _CASH_DEBIT_CARD_HPP_
#define _CASH_DEBIT_CARD_HPP_
#include <iostream>
#include <string>
const double BAL = 100.00;
const double CHARGE = 30.00;
class CashCard
{
private:
  // Private variables
  double balance_;
  std::string name_;

protected:
  // Protected variables
  double charge_balance(double a) { return balance_ -= a; }

public:
  // Constructors
  CashCard() : balance_(BAL), name_("Alex Amarnani"){};
  CashCard(double b, const std::string & n) : balance_(b), name_(n){};
  // Setters and Getters
  void set_balance(double b) { balance_ = b; }
  void set_name(const std::string & n) { name_ = n; }
  double balance() { return balance_; }
  std::string name() const { return name_; }
  // Charge the card
  void charge(double amount)
  {
    if (amount <= balance_)
    {
      charge_balance(amount);
    }
    else
    {
      std::cout << "Insufficient funds" << std::endl;
    }
  }
};

// Class connected to Cash Card
class DebitCard : public CashCard
{
public:
  // Constructors
  DebitCard() : CashCard(BAL, "Sidney Lee"){};
  DebitCard(double b, const std::string & n) : CashCard(b, n){};
  // Overrider function
  void charge(double a)
  {
    if (a > balance())
    {
      charge_balance(CHARGE);
      std::cout << "Overdraft Fee of $30.00 Incurred" << std::endl;
    }
    charge_balance(a);
  }
};

#endif
