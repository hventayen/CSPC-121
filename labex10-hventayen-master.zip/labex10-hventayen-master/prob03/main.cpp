#include "super_enemy.hpp"
#include <iostream>

int main()
{
  // Create an instance of the enemy class

  // Create an instance of the super_enemy class

  // Call the enemy's display method

  std::cout << "\n";
  // Call the super_enemy's display method

  std::cout << "\n";
  // Have both instances call their respective move_up and move_right...
  // ...methods 10 times
  for (int i = 0; i < 10; i++)
  {
    // place codes here
  }
  // Have both instances call their respective move_down and move_left...
  // ...methods 5 times
  for (int i = 0; i < 5; i++)
  {
    // place codes here
  }
  // Call the enemy's level_up method

  // Call the super_enemy's level_up method

  // Call the enemy's display method

  std::cout << "\n";
  // Call the super_enemy's display method

  return 0;
}
