#ifndef _UTENSILS_HPP_
#define _UTENSILS_HPP_
#include <iostream>
const double MASS = 1000;
const double SIZE = 8.5;
const double CSIZE = 6;
const double BSIZE = 25;
class Food
{
private:
  // Private members
  std::string name_;
  double mass_;

public:
  // Constructors
  Food() : name_("Apple Pie"), mass_(MASS){};
  Food(const std::string & n, double m) : name_(n), mass_(m){};
  // Setters and getters
  void set_name(const std::string & n) { name_ = n; }
  void set_mass(double m) { mass_ = m; }
  std::string name() const { return name_; }
  double mass() const { return mass_; }
  // Member functions
  void eat(double x)
  {
    mass_ -= x;
    if (mass_ < 0)
    {
      mass_ = 0;
    }
  }
  void print() { std::cout << name_ << " " << mass_ << "g" << std::endl; }
};

class Utensil
{
private:
  // Private members
  double size_;
  std::string color_;

public:
  // Constructors
  Utensil() : size_(SIZE), color_("silver"){};
  Utensil(double s, const std::string & c) : size_(s), color_(c){};
  // Setters and getters
  void set_size(double s) { size_ = s; }
  void set_color(const std::string & c) { color_ = c; }
  double size() { return size_; }
  std::string color() const { return color_; }
  // Member functions
  void use(Food & food){};
};

// Connects it to Utensil class
class Spoon : public Utensil
{
private:
  // Private members
  double bite_size_;

public:
  // Constructors
  Spoon() : Utensil(CSIZE, "silver"), bite_size_(BSIZE){};
  Spoon(double s, const std::string & c, double b)
      : Utensil(s, c), bite_size_(b){};
  // Setters and getters
  void set_bite_size(double b) { bite_size_ = b; }
  double bite_size() { return bite_size_; }
  void use(Food & food) { food.eat(bite_size_); }
};

#endif
